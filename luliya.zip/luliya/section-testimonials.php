  <!-- Link Swiper's CSS -->
  <link rel="stylesheet" href="http://10.10.10.44/wordpress/wp-content/themes/onepress/assets/css/swiper-bundle.min.css">

  <!-- Demo styles -->
  <style>
    html,
    body {
      position: relative;
      height: 100%;
    }

    body {
      background: #eee;
      font-family: Helvetica Neue, Helvetica, Arial, sans-serif;
      font-size: 14px;
      color: #000;
      margin: 0;
      padding: 0;
    }

    .swiper-container {
      width: 100%;
      height: 100%;

    }

    .swiper-slide {
      text-align: center;
      font-size: 18px;
      background: #fff;

      /* Center slide text vertically */
      display: -webkit-box;
      display: -ms-flexbox;
      display: -webkit-flex;
      display: flex;
      -webkit-box-pack: center;
      -ms-flex-pack: center;
      -webkit-justify-content: center;
      justify-content: center;
      -webkit-box-align: center;
      -ms-flex-align: center;
      -webkit-align-items: center;
      align-items: center;
    }

@media only screen and (min-width: 768px) {
	
.dt-testimonial-desc {
 font-size:18px;
 font-weight:400;
 line-height:1.7em;
 padding:35px 100px 20px;
 opacity:.8
}
}
@media only screen and (max-width: 768px) {

 .dt-testimonial-desc {
 font-size:18px;
 font-weight:400;
 line-height:1.7em;
 opacity:.8
}
}

.dt-testimonial-meta figure {
 position:relative;
 overflow:hidden;
 width:96px;
 height:96px;
 margin:10px auto;
 border-radius:50%
}
.dt-testimonial-meta figure img {
 position:absolute;
 top:-9999px;
 right:-9999px;
 bottom:-9999px;
 left:-9999px;
 width:auto;
 min-width:100%;
 max-width:500%;
 height:100%;
 margin:auto
}
.dt-testimonial-meta h5 {
 font-size:18px;
 margin:20px 0 5px;
 text-transform:capitalize
}
.dt-testimonial-meta span {
 display:block;
 margin-top:5px;
 font-size:15px;
 opacity:.7
}
.dt-testimonial-slider .swiper-button-next,
.dt-testimonial-slider .swiper-button-prev {
 z-index:999;
 right:20px;
 width:48px;
 height:60px;
 margin-top:-24px;
 padding-top:10px;
 text-align:center;
 opacity:.4;
 background:transparent;
 filter:alpha(opacity=40)
}
.dt-testimonial-slider .swiper-button-prev {
 left:20px
}
.dt-testimonial-slider .swiper-button-next:hover,
.dt-testimonial-slider .swiper-button-prev:hover {
 opacity:1;
 filter:alpha(opacity=100)
}
.dt-testimonial-slider .swiper-button-next .fa,
.dt-testimonial-slider .swiper-button-prev .fa {
 font-size:42px;
 color:rgba(0,0,0,.6)
}
  </style>
  <?php
$id       = get_theme_mod( 'onepress_team_id', esc_html__('team', 'onepress') );
$disable  = get_theme_mod( 'onepress_team_disable' ) ==  1 ? true : false;
$title    = get_theme_mod( 'onepress_team_title', esc_html__('What Clents Says', 'onepress' ));
$subtitle = get_theme_mod( 'onepress_team_subtitle', esc_html__('Section subtitle', 'onepress' ));
$layout   = intval( get_theme_mod( 'onepress_team_layout', 3 ) );
if ( $layout <= 0 ){
    $layout = 3;
}
$user_ids = onepress_get_section_team_data();
if ( onepress_is_selective_refresh() ) {
    $disable = false;
}
if ( ! empty( $user_ids ) ) {
    $desc = get_theme_mod( 'onepress_team_desc' );
    ?>
    <?php if ( ! $disable ) : ?>
        <?php if ( ! onepress_is_selective_refresh() ){ ?>
        <section id="<?php if ($id != '') { echo esc_attr( $id ); }; ?>" <?php do_action('onepress_section_atts', 'team'); ?>
                 class="<?php echo esc_attr(apply_filters('onepress_section_class', 'section-team section-padding section-meta onepage-section', 'team')); ?>">
        <?php } ?>
            <?php do_action('onepress_section_before_inner', 'team'); ?>
            <div class="<?php echo esc_attr( apply_filters( 'onepress_section_container_class', 'container', 'team' ) ); ?>">
                <?php if ( $title || $desc ){ ?>
                <div class="section-title-area">
                    
                    <?php if ($title != '') echo '<h2 class="section-title">' . esc_html($title) . '</h2>'; ?>
                    
                </div>
                <?php } ?>
                  <!-- Swiper -->
  <div class="swiper-container">
    <div class="swiper-wrapper"><div class="swiper-slide"><div class="dt-testimonial-holder"><div class="dt-testimonial-desc"><p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem Vivamus elementum .</p></div><div class="dt-testimonial-meta"><figure><img src="https://demos.famethemes.com/passionate/wp-content/uploads/sites/35/2016/03/jaxon.jpg"
alt="Gary Harrel"/></figure><h5>Gary Harrel</h5> <span>ABC Inc</span></div></div></div><div class="swiper-slide"><div class="dt-testimonial-holder"><div class="dt-testimonial-desc"><p>In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae ipsum dolor sit amet</p></div><div class="dt-testimonial-meta"><figure><img src="https://demos.famethemes.com/passionate/wp-content/uploads/sites/35/2016/03/two.jpg"
alt="Sandra Brown"/></figure><h5>Sandra Brown</h5> <span>Bright Future Technology</span></div></div></div><div class="swiper-slide"><div class="dt-testimonial-holder"><div class="dt-testimonial-desc"><p>Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum Integer tincidunt.</p></div><div class="dt-testimonial-meta"><figure><img src="https://demos.famethemes.com/passionate/wp-content/uploads/sites/35/2016/03/nine.jpg"
alt="Luiza Clacher"/></figure><h5>Luiza Clacher</h5> <span>Creative Magazine</span></div></div></div></div>
    <!-- Add Pagination -->
   
    <!-- Add Arrows -->
    <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
  </div>
            </div>
            <?php do_action('onepress_section_after_inner', 'team'); ?>
        <?php if ( ! onepress_is_selective_refresh() ){ ?>
        </section>
        <?php } ?>
    <?php endif;
}

?>
  <!-- Swiper JS -->
  <script src="http://10.10.10.44/wordpress/wp-content/themes/onepress/assets/js/swiper-bundle.min.js"></script>

  <!-- Initialize Swiper -->
  <script>
    var swiper = new Swiper('.swiper-container', {
      spaceBetween: 30,
      centeredSlides: true,
      autoplay: {
        delay: 2500,
        disableOnInteraction: false,
      },
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
    });
  </script>